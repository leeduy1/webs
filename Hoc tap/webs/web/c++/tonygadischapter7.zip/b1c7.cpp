#include <iostream>
#include<algorithm>

using namespace std;

int main() {
	int n = 10;
	int arr[n];
	for(int i=0; i < n; i++) {
		cin >> arr[i];
    }
    
    sort(arr, arr + n);
    cout << arr[9] << endl;
    cout << arr[0];
}

